<?php
    require_once("../config.php");
    if($REQ === "POST"){
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        //Generate a random string.
        $token = openssl_random_pseudo_bytes(16);
         
        //Convert the binary data into hexadecimal representation.
        $token = bin2hex($token);
        
        $token = bin2hex($token);
        
        $getUser = $conn->query("SELECT first_name, last_name, email, phone, password, user_id  FROM users WHERE email='$email' AND password='$password'");
        if($getUser->num_rows > 0){
            $row = $getUser->fetch_assoc();
            $user_id = $row['user_id'];
            $conn->query("DELETE FROM token WHERE user_id='$user_id'");
            
            $response = array(
                "code" => 200,
                "message" => "Login successful",
                "token" => $token,
                "user_id" => $user_id
            );
            $conn->query("INSERT INTO token (token, user_id) VALUES ('$token', '$user_id')");
        }else{
            $response = array(
                "code" => 401,
                "message" => "Invalid login details"
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>