<?php
    require_once("../config.php");
    if($REQ === "POST"){
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $first_name = $_POST['firstname'];
        $last_name = $_POST['lastname'];
        $phone = $_POST['phone'];
        $getUser = $conn->query("SELECT * FROM users WHERE email='$email'");
        if($getUser->num_rows > 0){
            $response = array(
                "code" => 400,
                "message" => "User $email already exist"
            );
        }else{
            $rand = rand(99999, 99999999);
            $rand_ = rand(9999, 99999999);
            $rand__ = rand(999, 999999999);
            $userid = "$rand-$rand_-$rand__";
            $conn->query("INSERT INTO users (first_name, last_name, email, phone, password, user_id) VALUES ('$first_name', '$last_name', '$email', '$phone', '$password', '$userid')");
            $response = array(
                "code" => 200,
                "message" => "registration successful",
                "user" => $_POST
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>