<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "genesis36_app", "genesis360#2022", "genesis36_app");
    $REQ = $_SERVER['REQUEST_METHOD'];
    $headers = getallheaders();
?>