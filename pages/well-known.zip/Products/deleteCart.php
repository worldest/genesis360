<?php
    require_once("../config.php");
    $token = Token::getBearerToken();
    if($REQ === "GET"){
        $id = $_GET['id'];
        $conn->query("DELETE FROM cart WHERE id='$id'");
        $response = array(
            "code" => 200,
            "message" => "Item deleted from cart"
        );
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>