<?php
    require_once("../config.php");
    $token = Token::getBearerToken();
    if($REQ === "POST"){
        $userid = $_POST['userid'];
        $id = $_POST['id'];
        $price = $_POST['price'] * $_POST['qty'];
        $qty = $_POST['qty'];
        if($token !== null){
            $checkToken = $conn->query("SELECT * FROM token WHERE token='$token'");
            if($checkToken->num_rows > 0){
                $conn->query("INSERT INTO cart (userid, product_id, price, qty) VALUES ('$userid', '$id', '$price', '$qty')");
                $response = array(
                    "code" => 200,
                    "message" => "Product added to cart"
                );
            }else{
                $response = array(
                    "code" => 401,
                    "message" => "Invalid Authorization token"
                );
            }
        }else{
            $response = array(
                "code" => 401,
                "message" => "Invalid Authorization token or user not authorized"
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>