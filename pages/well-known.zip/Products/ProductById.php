<?php
    require_once("../config.php");
    if($REQ === "GET"){
        $id = $_GET['id'];
        $getProducts = $conn->query("SELECT * FROM products WHERE id='$id' ORDER BY id DESC");
        if($getProducts->num_rows > 0){
            while($row = $getProducts->fetch_assoc()){
                $response = $row;
            }
        }else{
            $response[] = array(
                
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>