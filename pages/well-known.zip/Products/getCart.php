<?php
    require_once("../config.php");
    $token = Token::getBearerToken();
    if($REQ === "GET"){
        $userid = $_GET['userid'];
        if($token !== null){
            $checkToken = $conn->query("SELECT * FROM token WHERE token='$token'");
            if($checkToken->num_rows > 0){
                $getUser = $conn->query("SELECT * FROM cart WHERE userid='$userid' AND status='0'");
                if($getUser->num_rows > 0){
                    $total = 0;
                    while($row = $getUser->fetch_assoc()){
                        $total += $row['price']; 
                        $product_id = $row['product_id'];
                        $getProd = $conn->query("SELECT * FROM products WHERE id='$product_id'");
                        $prod = $getProd->fetch_assoc();
                        $cartt[] = array(
                            "cart_info" => $row,
                            "product" => $prod
                        );
                    }
                    $response = array(
                        "code" => 200,
                        "message" => "Cart Fetched",
                        "cart" => $cartt,
                        "total" => $total
                    );
                    
                }else{
                    $response = array(
                        "code" => 302,
                        "message" => "Account not found, please login or register"
                    );
                }
            }else{
                $response = array(
                    "code" => 401,
                    "message" => "Invalid Authorization token"
                );
            }
        }else{
            $response = array(
                "code" => 401,
                "message" => "Invalid Authorization token or user not authorized"
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>