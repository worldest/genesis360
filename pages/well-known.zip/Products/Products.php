<?php
    require_once("../config.php");
    if($REQ === "GET"){
        $getProducts = $conn->query("SELECT * FROM products ORDER BY id DESC");
        if($getProducts->num_rows > 0){
            while($row = $getProducts->fetch_assoc()){
                $response[] = $row;
            }
        }else{
            $response[] = array(
                
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
    
    // $token = Token::getBearerToken();
    // if($REQ === "GET"){
    //     if($token !== null){
    //         $checkToken = $conn->query("SELECT token from token WHERE token='$token'");
    //         if($checkToken->num_rows > 0){
    //             $getProducts = $conn->query("SELECT * FROM products ORDER BY id DESC");
    //             if($getProducts->num_rows > 0){
    //                 while($row = $getProducts->fetch_assoc()){
    //                     $response[] = $row;
    //                 }
    //             }else{
    //                 $response[] = array(
                        
    //                 );
    //             }
    //         }else{
    //             $response = array(
    //                 "code" => 401,
    //                 "message" => "Invalid Authorization token"
    //             );
    //         }
    //     }else{
    //         $response = array(
    //             "code" => 401,
    //             "message" => "Invalid Authorization token or user not authorized"
    //         );
    //     }
    // }else{
    //     $response = array(
    //         "code" => 405,
    //         "message" => "Invalid method"
    //     );
    // }
    // echo json_encode($response);
?>