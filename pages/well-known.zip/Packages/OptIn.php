<?php
    require_once("../config.php");
    $token = Token::getBearerToken();
    if($REQ === "POST"){
        $userid = $_POST['userid'];
        $package = $_POST['package'];
        if($token !== null){
            $checkToken = $conn->query("SELECT * FROM token WHERE token='$token'");
            if($checkToken->num_rows > 0){
                $getKYC = $conn->query("SELECT * FROM kyc WHERE userid='$userid' AND status='1'");
                if($getKYC->num_rows > 0){
                    $getSub = $conn->query("SELECT * FROM subscriptions WHERE userid='$userid' AND status='0'");
                    if($getSub->num_rows > 0){
                        $response = array(
                            "code" => 301,
                            "message" => "You still have an active subscription"
                        );
                    }else if($getSub->num_rows <= 0){
                        $getProducts = $conn->query("SELECT * FROM products WHERE package_id='$package'");
                        $price = 0;
                        if($getProducts->num_rows > 0){
                            while($row = $getProducts->fetch_assoc()){
                                $price += $row['price'];
                            }
                        }
                        $conn->query("INSERT INTO subscriptions (userid, package_, price) VALUES ('$userid', '$package', '$price')");
                        $response = array(
                            "code" => 200,
                            "message" => "You have successfully opt in for this package. Thanks"
                        );
                    }
                }else{
                    $response = array(
                        "code" => 302,
                        "message" => "Please complete KYC Or your KYC is pending"
                    );
                }
            }else{
                $response = array(
                    "code" => 401,
                    "message" => "Invalid Authorization token"
                );
            }
        }else{
            $response = array(
                "code" => 401,
                "message" => "Invalid Authorization token or user not authorized"
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>