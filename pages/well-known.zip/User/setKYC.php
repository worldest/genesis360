<?php
    require_once("../config.php");
    $token = Token::getBearerToken();
    if($REQ === "POST"){
        $userid = $_POST['userid'];
        $gender = $_POST['gender'];
        $income = $_POST['income'];
        $num = $_POST['num'];
        $remita = $_POST['remita'];
        if($token !== null){
            $checkToken = $conn->query("SELECT * FROM token WHERE token='$token'");
            if($checkToken->num_rows > 0){
                $getUser = $conn->query("SELECT * FROM kyc WHERE userid='$userid'");
                if($getUser->num_rows > 0){
                    $response = array(
                        "code" => 200,
                        "message" => "You have already filled the KYC form",
                        "kyc" => $getUser->fetch_assoc()
                    );
                    
                }else{
                    $conn->query("INSERT INTO kyc (userid, remita, gender, income, family_num) VALUES ('$userid', '$remita', '$gender', '$income', '$num')");
                    $response = array(
                        "code" => 200,
                        "message" => "KYC submitted successfully and awaiting confirmation"
                    );
                }
            }else{
                $response = array(
                    "code" => 401,
                    "message" => "Invalid Authorization token"
                );
            }
        }else{
            $response = array(
                "code" => 401,
                "message" => "Invalid Authorization token or user not authorized"
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>