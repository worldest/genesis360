<?php
    require_once("../config.php");
    $token = Token::getBearerToken();
    if($REQ === "GET"){
        $userid = $_GET['userid'];
        if($token !== null){
            $checkToken = $conn->query("SELECT * FROM token WHERE token='$token'");
            if($checkToken->num_rows > 0){
                $getUser = $conn->query("SELECT * FROM kyc WHERE userid='$userid'");
                if($getUser->num_rows > 0){
                    $response = array(
                        "code" => 200,
                        "message" => "Profile Fetch",
                        "kyc" => $getUser->fetch_assoc()
                    );
                    
                }else{
                    $response = array(
                        "code" => 302,
                        "message" => "Account not found, please login or register"
                    );
                }
            }else{
                $response = array(
                    "code" => 401,
                    "message" => "Invalid Authorization token"
                );
            }
        }else{
            $response = array(
                "code" => 401,
                "message" => "Invalid Authorization token or user not authorized"
            );
        }
    }else{
        $response = array(
            "code" => 405,
            "message" => "Invalid method"
        );
    }
    echo json_encode($response);
?>